<script setup>
import { onMounted } from "@vue/runtime-core";
import mqtt from "mqtt";
import { StatusBar, Style } from "@capacitor/status-bar";
//---------------------------------------//
import { dataDaftarTopikMQTT } from "../dataStorePusat/dataDaftarTopikMQTT";
//
let daftar_topik_MQTT = dataDaftarTopikMQTT();
//---------------------------------------//
import { dataMonitorHardwareGreenhouse1 } from "../dataStorePusat/greenhouse1/dataMonitorGreenhouse1";
import { dataMonitorHardwareGreenhouse2 } from "../dataStorePusat/greenhouse2/dataMonitorGreenhouse2";
import { dataMonitorHardwareGreenhouse3 } from "../dataStorePusat/greenhouse3/dataMonitorGreenhouse3";
import { dataMonitorHardwareMediaTanah } from "../dataStorePusat/mediatanah/dataMonitorMediaTanah";
//
import { dataKontrolHardwareGreenhouse1 } from "../dataStorePusat/greenhouse1/dataKontrolGreenhouse1";
import { dataKontrolHardwareGreenhouse2 } from "../dataStorePusat/greenhouse2/dataKontrolGreenhouse2";
import { dataKontrolHardwareGreenhouse3 } from "../dataStorePusat/greenhouse3/dataKontrolGreenhouse3";
import { dataKontrolHardwareMediaTanah } from "../dataStorePusat/mediatanah/dataKontrolMediaTanah";
//
const monitor_hardware_greenhouse1 = dataMonitorHardwareGreenhouse1();
const monitor_hardware_greenhouse2 = dataMonitorHardwareGreenhouse2();
const monitor_hardware_greenhouse3 = dataMonitorHardwareGreenhouse3();
const monitor_hardware_mediatanah = dataMonitorHardwareMediaTanah();
//
const kontrol_hardware_greenhouse1 = dataKontrolHardwareGreenhouse1();
const kontrol_hardware_greenhouse2 = dataKontrolHardwareGreenhouse2();
const kontrol_hardware_greenhouse3 = dataKontrolHardwareGreenhouse3();
const kontrol_hardware_mediatanah = dataKontrolHardwareMediaTanah();
//---------------------------------------//
const host = "localhost";
const port = 8883;
let client = { connected: false };
let opt = {
  keepalive: 60,
  protocolId: "MQIsdp",
  protocolVersion: 3,
  clean: false, // Reserved session
  connectTimeout: 4000, // Time out
  reconnectPeriod: 4000, // Reconnection interval
  clientId: "mqttjs_" + Math.random().toString(16).substr(2, 8), // ClientID
  username: "user", // Username
  password: "user", // Password
};
let { ...options } = opt;
const connectUrl = `http://${host}:${port}/mqtt`;
const topikMqtt = {
  topic: daftar_topik_MQTT.topikMQTTSerpisKeseluruhan,
  qos: 0,
};
//---------------------------------------//
function buatKoneksi() {
  console.log("Memulai Koneksi...");
  try {
    client = mqtt.connect(connectUrl, options);
    client.on("connect", () => {
      console.log("Terhubung :" + client.connected);
      subscribeKeTopic();
      pesanMqttMasuk();
      //publishPesan();
    });
  } catch (error) {
    console.log("Error:", error);
  }

  client.on("error", (error) => {
    console.log("Connection failed", error);
  });
}

function subscribeKeTopic() {
  const { topic, qos } = topikMqtt;
  client.subscribe(topic, qos, (error, res) => {
    if (error) {
      console.log("Gagal Subscribe", error);
      return;
    }
    console.log("Berhasil Subscribe ke topics :", res);
  });
}

function pesanMqttMasuk() {
  client.on("message", (topic, message) => {
    console.log(`Pesan Masuk : ${message} \ndari Topic : ${topic}`);
    switch (topic) {
      //----------------GREENHOUSE 1-----------------------------------//
      case daftar_topik_MQTT.greenhouse1Temperatur:
        monitor_hardware_greenhouse1.temperatur = String(message);
        break;
      case daftar_topik_MQTT.greenhouse1Kelembaban:
        monitor_hardware_greenhouse1.kelembaban = String(message);
        break;
      case daftar_topik_MQTT.greenhouse1PompaSprayer:
        monitor_hardware_greenhouse1.pompaSprayer = String(message);
        break;
      case daftar_topik_MQTT.greenhouse1TandonSprayer:
        monitor_hardware_greenhouse1.airTandonSprayer = String(message);
        break;
      //-----//
      case daftar_topik_MQTT.greenhouse1AirNutrisiHidroponik1:
        monitor_hardware_greenhouse1.airNutrisiHidroponik1 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse1AirNutrisiHidroponik2:
        monitor_hardware_greenhouse1.airNutrisiHidroponik2 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse1AirNutrisiHidroponik3:
        monitor_hardware_greenhouse1.airNutrisiHidroponik3 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse1AirNutrisiHidroponik4:
        monitor_hardware_greenhouse1.airNutrisiHidroponik4 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse1AirNutrisiHidroponik5:
        monitor_hardware_greenhouse1.airNutrisiHidroponik5 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse1AirNutrisiHidroponik6:
        monitor_hardware_greenhouse1.airNutrisiHidroponik6 = String(message);
        break;
      //----------------GREENHOUSE 2-----------------------------------//
      case daftar_topik_MQTT.greenhouse2Temperatur:
        monitor_hardware_greenhouse2.temperatur = String(message);
        break;
      case daftar_topik_MQTT.greenhouse2Kelembaban:
        monitor_hardware_greenhouse2.kelembaban = String(message);
        break;
      case daftar_topik_MQTT.greenhouse2PompaSprayer:
        monitor_hardware_greenhouse2.pompaSprayer = String(message);
        break;
      case daftar_topik_MQTT.greenhouse2TandonSprayer:
        monitor_hardware_greenhouse2.airTandonSprayer = String(message);
        break;
      //-----//
      case daftar_topik_MQTT.greenhouse2AirNutrisiHidroponik1:
        monitor_hardware_greenhouse2.airNutrisiHidroponik1 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse2AirNutrisiHidroponik2:
        monitor_hardware_greenhouse2.airNutrisiHidroponik2 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse2AirNutrisiHidroponik3:
        monitor_hardware_greenhouse2.airNutrisiHidroponik3 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse2AirNutrisiHidroponik4:
        monitor_hardware_greenhouse2.airNutrisiHidroponik4 = String(message);
        break;
      //----------------GREENHOUSE 3-----------------------------------//
      case daftar_topik_MQTT.greenhouse3Temperatur:
        monitor_hardware_greenhouse3.temperatur = String(message);
        break;
      case daftar_topik_MQTT.greenhouse3Kelembaban:
        monitor_hardware_greenhouse3.kelembaban = String(message);
        break;
      case daftar_topik_MQTT.greenhouse3PompaSprayer:
        monitor_hardware_greenhouse3.pompaSprayer = String(message);
        break;
      case daftar_topik_MQTT.greenhouse3TandonSprayer:
        monitor_hardware_greenhouse3.airTandonSprayer = String(message);
        break;
      //-----//
      case daftar_topik_MQTT.greenhouse3AirNutrisiHidroponik1:
        monitor_hardware_greenhouse3.airNutrisiHidroponik1 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse3AirNutrisiHidroponik2:
        monitor_hardware_greenhouse3.airNutrisiHidroponik2 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse3AirNutrisiHidroponik3:
        monitor_hardware_greenhouse3.airNutrisiHidroponik3 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse3AirNutrisiHidroponik4:
        monitor_hardware_greenhouse3.airNutrisiHidroponik4 = String(message);
        break;
      case daftar_topik_MQTT.greenhouse3AirNutrisiHidroponik5:
        monitor_hardware_greenhouse3.airNutrisiHidroponik5 = String(message);
        break;
      //----------------MEDIA TANAH-----------------------------------//

      //-----//
    }
  });
}

kontrol_hardware_greenhouse1.$subscribe((mutation, state) => {
  if (state.kontrolpompaSprayer === "ON") {
    client.publish(daftar_topik_MQTT.kontrolGreenhouse1PompaSprayer, "ON", 0);
  } else {
    client.publish(daftar_topik_MQTT.kontrolGreenhouse1PompaSprayer, "OFF", 0);
  }
});

kontrol_hardware_greenhouse2.$subscribe((mutation, state) => {
  if (state.kontrolpompaSprayer === "ON") {
    client.publish(daftar_topik_MQTT.kontrolGreenhouse2PompaSprayer, "ON", 0);
  } else {
    client.publish(daftar_topik_MQTT.kontrolGreenhouse2PompaSprayer, "OFF", 0);
  }
});

kontrol_hardware_greenhouse3.$subscribe((mutation, state) => {
  if (state.kontrolpompaSprayer === "ON") {
    client.publish(daftar_topik_MQTT.kontrolGreenhouse3PompaSprayer, "ON", 0);
  } else {
    client.publish(daftar_topik_MQTT.kontrolGreenhouse3PompaSprayer, "OFF", 0);
  }
});

function setStatusBarStyleLight() {
  //await StatusBar.setStyle({ style: Style.Dark });
  try {
    StatusBar.setOverlaysWebView({ overlay: true });
    console.log("Set Status Bar Android Full");
  } catch (error) {
    console.log(error);
  }
}

onMounted(() => {
  buatKoneksi();
  setStatusBarStyleLight();
});
</script>

<template></template>
