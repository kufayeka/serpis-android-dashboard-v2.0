<script setup>
import { onMounted } from "@vue/runtime-core";
import { StatusBar, Style } from "@capacitor/status-bar";
const axios = require("axios");
//---------------------------------------//
function setStatusBarStyleLight() {
  try {
    StatusBar.setOverlaysWebView({ overlay: true });
    console.log("Set Status Bar Android Full");
  } catch (error) {
    console.log(error);
  }
}
//---------------------------------------//
function buatKoneksi() {
  console.log("Hi BITCHH lets start it over... puftt");

  axios
    .get("/")
    .then(function (response) {
      // handle success
      console.log(response.data);
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    });
}
//---------------------------------------//
onMounted(() => {
  buatKoneksi();
  setStatusBarStyleLight();
});
</script>

<style></style>

<template></template>
