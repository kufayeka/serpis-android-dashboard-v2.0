<script setup></script>

<style></style>

<template>
  <div class="flex flex-col w-full h-full">
    <!-------Panel Judul Halaman-------->
    <div class="bg-green-800 absolute w-full rounded-b-3xl -z-30">
      <img
        src="../assets/background/5476705_2832233.jpg"
        class="object-cover w-full h-52 scale-x-100 rounded-b-3xl opacity-40"
      />
    </div>
    <div class="grid justify-items-center mt-10">
      <p class="text-4xl text-white drop-shadow-xl font-bold tracking-wider">
        KRPL - SERPIS
      </p>
      <p class="text-2xl text-white drop-shadow-xl font-semibold tracking-widest">
        "Kebun Kita"
      </p>
    </div>
    <!-------Konten-------->
    <div class="flex flex-col relative top-7">
      <!-----Panel Info Halaman---------->
      <div class="border border-white rounded-xl p-1 mx-4">
        <div class="bg-white shadow-card rounded-xl p-3 flex flex-row space-x-3">
          <div class="bg-white rounded-full flex p-3 h-20 w-32">
            <img
              src="../assets/icons/icons8-adjust-100.png"
              class="object-contain w-28"
            />
          </div>
          <div>
            <h1 class="text-lg font-extrabold tracking-wider">Pengaturan</h1>
            <p class="text-sm">Halaman pengaturan nyala pompa sprayer.</p>
          </div>
        </div>
      </div>
      <!-----Panel Pengaturan--------->
      <div class="grid justify-items-center mt-5">
        <div class="flex flex-col w-10/12 gap-4">
          <!---Pengaturan : Greenhouse 1----------->
          <div class="bg-green-700 rounded-md shadow-card flex flex-row">
            <img
              src="../assets/icons/icons8-support-100-cloud.png"
              class="object-contain w-12 ml-3"
            />
            <h1 class="text-white text-lg font-semibold tracking-wider mt-3 ml-3">
              Greenhouse 1
            </h1>
          </div>
          <!---Pengaturan : Greenhouse 2----------->
          <div class="bg-green-700 rounded-md shadow-card flex flex-row">
            <img
              src="../assets/icons/icons8-support-100-cloud.png"
              class="object-contain w-12 ml-3"
            />
            <h1 class="text-white text-lg font-semibold tracking-wider mt-3 ml-3">
              Greenhouse 2
            </h1>
          </div>
          <!---Pengaturan : Greenhouse 3----------->
          <div class="bg-green-700 rounded-md shadow-card flex flex-row">
            <img
              src="../assets/icons/icons8-support-100-cloud.png"
              class="object-contain w-12 ml-3"
            />
            <h1 class="text-white text-lg font-semibold tracking-wider mt-3 ml-3">
              Greenhouse 2
            </h1>
          </div>
          <!---Pengaturan : Media Tanah----------->
          <div class="bg-green-700 rounded-md shadow-card flex flex-row">
            <img
              src="../assets/icons/icons8-support-100-cloud.png"
              class="object-contain w-12 ml-3"
            />
            <h1 class="text-white text-lg font-semibold tracking-wider mt-3 ml-3">
              Media Tanah
            </h1>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
