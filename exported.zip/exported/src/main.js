import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'
import './assets/tailwind.css'
import store from './store'
import LottieAnimation from "lottie-web-vue";
import Axios from 'axios';

Axios.defaults.baseURL = 'http://203.189.120.137:3333';
Axios.defaults.headers.get['serpis'] = 'SERPIS GET';

const pinia = createPinia();

createApp(App)
.use(store)
.use(store)
.use(router)
.use(pinia)
.use(LottieAnimation)
.mount('#app')
