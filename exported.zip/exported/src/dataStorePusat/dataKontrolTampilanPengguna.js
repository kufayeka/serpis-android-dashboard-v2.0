import { defineStore } from 'pinia'

export const dataKontrolTampilanPengguna = defineStore({
  id: "data.kontrol.tampilan.pengguna",
  state: () => {
    return { 
        tampilan_pengguna: 'monitor',
        konten_tab_monitor : 'tutup',
    }
  },
  actions: {
    ubahTampilan(tampilan){
        this.tampilan_pengguna = tampilan;
    },

    bukaKontenTabMonitor(konten){
        this.konten_tab_monitor = konten;
    }
  }
})